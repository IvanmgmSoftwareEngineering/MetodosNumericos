%% PRACTICA 1.4: RESOLUCION DE SISTEMAS DE ECUCACIONES LINEALES
%  RESOLUCION DE SISTEMAS DE ECUACIONES LINEALES POR JACOBI y GAUSS-SEIDEL (Metodo Iterativo)
%  EJERCICIO 1
%  Script1.m
%  AUTOR: IVAN MARTIN GOMEZ

%----------------------------------------------------------------------------------
close all;
clear all;
clc;
format long;



        % Introduciomos los datos del Ejercicio
        
            A=[3 -0.1 -0.2;0.1 7 -0.3;0.3 -0.2 10]
            b=[7.85;-19.3;71.4]
            x_sol=[3 -2.5 7];
            tolerancia=10^-11;
            x_0= [0 0 0];
            
% RESOLVEMOS POR JACOBI

        % Llamamos a la funcion jacobi.m
            tStart=tic; % Tomamos captura de la hora actual
            [x_aproximaciones_jacobi, error_1_jacobi, error_2_jacobi] = jacobi(A,b,tolerancia,x_0,x_sol)
            tiempo_jacobi=toc(tStart)% Tomamos captura de la hora actual y calculamos la diferecnia
            tolerancia %Imprimimos por vantana de comandos el valor de la Tolerancia

        % Donde:
            % error_1_jacobi: es el error calculado con la Solucion Exacta (x_sol)   
            % error_2_jacobi: es el error calculado con la Iteracion anterior 
                
        
% FIN JACOBI 
% ----------------------------------------------------------------------------             
% ----------------------------------------------------------------------------             
% RESOLVEMOS POR GAUSS-SEIDEL                 
            % Llamamos a la funcion gauss_seidel.m
               tStart=tic; % Tomamos captura de la hora actual
               [x_aproximaciones_gauss, error_1_gauss, error_2_gauss] = gauss_seidel(A,b,tolerancia,x_0,x_sol)
               tiempo_gauss_seidel=toc(tStart)% Tomamos captura de la hora actual y calculamos la diferecnia
               tolerancia %Imprimimos por vantana de comandos el valor de la Tolerancia
        
            % Donde:
                % error_1_gauss: es el error calculado con la Solucion Real (x_sol)
                % error_2_gauss: es el error calculado con la Iteracion anterior 

% FIN GAUSS-SEIDEL   
% ----------------------------------------------------------------------------             
% ----------------------------------------------------------------------------             
           
                    
                    